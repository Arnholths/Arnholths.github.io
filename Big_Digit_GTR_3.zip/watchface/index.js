﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_weather_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_pai_weekly_text_img = ''
        let normal_pai_weekly_separator_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_system_lock_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_minute_separator_img = ''
        let normal_step_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let Button_1 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 130,
              y: 385,
              image_array: ["0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 210,
              y: 400,
              font_array: ["nummed000.png","nummed001.png","nummed002.png","nummed003.png","nummed004.png","nummed005.png","nummed006.png","nummed007.png","nummed008.png","nummed009.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'nummedcelcius.png',
              unit_tc: 'nummedcelcius.png',
              unit_en: 'nummedcelcius.png',
              negative_image: 'nummedminus.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 370,
              y: 336,
              font_array: ["numsmall000.png","numsmall001.png","numsmall002.png","numsmall003.png","numsmall004.png","numsmall005.png","numsmall006.png","numsmall007.png","numsmall008.png","numsmall009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 325,
              y: 335,
              src: 'hr.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 245,
              y: 335,
              font_array: ["numsmall000.png","numsmall001.png","numsmall002.png","numsmall003.png","numsmall004.png","numsmall005.png","numsmall006.png","numsmall007.png","numsmall008.png","numsmall009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 210,
              y: 335,
              src: 'pai.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 95,
              y: 335,
              font_array: ["numsmall000.png","numsmall001.png","numsmall002.png","numsmall003.png","numsmall004.png","numsmall005.png","numsmall006.png","numsmall007.png","numsmall008.png","numsmall009.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 50,
              y: 330,
              src: 'steeps.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 180,
              y: 20,
              src: '0075.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 270,
              y: 20,
              src: '0077.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 225,
              y: 20,
              src: '0076.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 80,
              y: 80,
              week_en: ["day1.png","day2.png","day3.png","day4.png","day5.png","day6.png","day7.png"],
              week_tc: ["day1.png","day2.png","day3.png","day4.png","day5.png","day6.png","day7.png"],
              week_sc: ["day1.png","day2.png","day3.png","day4.png","day5.png","day6.png","day7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 240,
              month_startY: 73,
              month_sc_array: ["nummed000.png","nummed001.png","nummed002.png","nummed003.png","nummed004.png","nummed005.png","nummed006.png","nummed007.png","nummed008.png","nummed009.png"],
              month_tc_array: ["nummed000.png","nummed001.png","nummed002.png","nummed003.png","nummed004.png","nummed005.png","nummed006.png","nummed007.png","nummed008.png","nummed009.png"],
              month_en_array: ["nummed000.png","nummed001.png","nummed002.png","nummed003.png","nummed004.png","nummed005.png","nummed006.png","nummed007.png","nummed008.png","nummed009.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 320,
              month_startY: 70,
              month_sc_array: ["month001.png","month002.png","month003.png","month004.png","month005.png","month006.png","month007.png","month008.png","month009.png","month010.png","month011.png","month012.png"],
              month_tc_array: ["month001.png","month002.png","month003.png","month004.png","month005.png","month006.png","month007.png","month008.png","month009.png","month010.png","month011.png","month012.png"],
              month_en_array: ["month001.png","month002.png","month003.png","month004.png","month005.png","month006.png","month007.png","month008.png","month009.png","month010.png","month011.png","month012.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 175,
              day_startY: 73,
              day_sc_array: ["nummed000.png","nummed001.png","nummed002.png","nummed003.png","nummed004.png","nummed005.png","nummed006.png","nummed007.png","nummed008.png","nummed009.png"],
              day_tc_array: ["nummed000.png","nummed001.png","nummed002.png","nummed003.png","nummed004.png","nummed005.png","nummed006.png","nummed007.png","nummed008.png","nummed009.png"],
              day_en_array: ["nummed000.png","nummed001.png","nummed002.png","nummed003.png","nummed004.png","nummed005.png","nummed006.png","nummed007.png","nummed008.png","nummed009.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: 'nummeddot.png',
              day_unit_tc: 'nummeddot.png',
              day_unit_en: 'nummeddot.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 30,
              hour_startY: 150,
              hour_array: ["num100.png","num101.png","num102.png","num103.png","num104.png","num105.png","num106.png","num107.png","num108.png","num109.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'numdot1.png',
              hour_unit_tc: 'numdot1.png',
              hour_unit_en: 'numdot1.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["num100.png","num101.png","num102.png","num103.png","num104.png","num105.png","num106.png","num107.png","num108.png","num109.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 80,
              y: 80,
              week_en: ["day1.png","day2.png","day3.png","day4.png","day5.png","day6.png","day7.png"],
              week_tc: ["day1.png","day2.png","day3.png","day4.png","day5.png","day6.png","day7.png"],
              week_sc: ["day1.png","day2.png","day3.png","day4.png","day5.png","day6.png","day7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 240,
              month_startY: 73,
              month_sc_array: ["nummed000.png","nummed001.png","nummed002.png","nummed003.png","nummed004.png","nummed005.png","nummed006.png","nummed007.png","nummed008.png","nummed009.png"],
              month_tc_array: ["nummed000.png","nummed001.png","nummed002.png","nummed003.png","nummed004.png","nummed005.png","nummed006.png","nummed007.png","nummed008.png","nummed009.png"],
              month_en_array: ["nummed000.png","nummed001.png","nummed002.png","nummed003.png","nummed004.png","nummed005.png","nummed006.png","nummed007.png","nummed008.png","nummed009.png"],
              month_zero: 0,
              month_space: 0,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 320,
              month_startY: 70,
              month_sc_array: ["month001.png","month002.png","month003.png","month004.png","month005.png","month006.png","month007.png","month008.png","month009.png","month010.png","month011.png","month012.png"],
              month_tc_array: ["month001.png","month002.png","month003.png","month004.png","month005.png","month006.png","month007.png","month008.png","month009.png","month010.png","month011.png","month012.png"],
              month_en_array: ["month001.png","month002.png","month003.png","month004.png","month005.png","month006.png","month007.png","month008.png","month009.png","month010.png","month011.png","month012.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 175,
              day_startY: 73,
              day_sc_array: ["nummed000.png","nummed001.png","nummed002.png","nummed003.png","nummed004.png","nummed005.png","nummed006.png","nummed007.png","nummed008.png","nummed009.png"],
              day_tc_array: ["nummed000.png","nummed001.png","nummed002.png","nummed003.png","nummed004.png","nummed005.png","nummed006.png","nummed007.png","nummed008.png","nummed009.png"],
              day_en_array: ["nummed000.png","nummed001.png","nummed002.png","nummed003.png","nummed004.png","nummed005.png","nummed006.png","nummed007.png","nummed008.png","nummed009.png"],
              day_zero: 0,
              day_space: 0,
              day_unit_sc: 'nummeddot.png',
              day_unit_tc: 'nummeddot.png',
              day_unit_en: 'nummeddot.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 30,
              hour_startY: 150,
              hour_array: ["num100.png","num101.png","num102.png","num103.png","num104.png","num105.png","num106.png","num107.png","num108.png","num109.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'numdot1.png',
              hour_unit_tc: 'numdot1.png',
              hour_unit_en: 'numdot1.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["num100.png","num101.png","num102.png","num103.png","num104.png","num105.png","num106.png","num107.png","num108.png","num109.png"],
              minute_zero: 0,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 10,
              y: 10,
              src: 'AODblend.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 50,
              y: 325,
              w: 150,
              h: 50,
              src: 'link.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 326,
              y: 325,
              w: 120,
              h: 50,
              src: 'link.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 210,
              y: 325,
              w: 100,
              h: 50,
              src: 'link.png',
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 130,
              y: 380,
              w: 220,
              h: 100,
              src: 'link.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 30,
              y: 150,
              w: 188,
              h: 153,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 265,
              y: 150,
              w: 188,
              h: 153,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 215,
              y: 10,
              w: 50,
              h: 50,
              src: 'link.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 80,
              y: 70,
              w: 330,
              h: 50,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: 'link.png',
              normal_src: 'link.png',
              click_func: (button_widget) => {
                hmApp.startApp({ appid: 1057409, url: 'page/index' });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}